package com.webtoon.autoscroller

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var widgetView: LinearLayout
    private lateinit var layoutParams: WindowManager.LayoutParams

    private lateinit var btnPlay: Button
    private lateinit var btnSize: Button
    private lateinit var btnToggle: Button
    private lateinit var txtSpeed: TextView
    private lateinit var speedSlider: SeekBar
    private lateinit var panelSlider: LinearLayout
    private lateinit var dragHandle: View

    private var isPlaying = false
    private var currentSpeedIndex = 13 // Default to 1.5x in our slider steps
    private var isExpanded = false
    
    // Scale sizes (Small, Medium, Large)
    private var currentScaleIndex = 1 // 0: Small, 1: Medium, 2: Large
    private val scales = floatArrayOf(0.8f, 1.0f, 1.2f)
    private val scaleLabels = arrayOf("0.8x", "1.0x", "1.2x")

    private val handler = Handler(Looper.getMainLooper())
    private var scrollRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // Create widget UI programmatically for robust setup
        widgetView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            // Premium Slate Background with Rounded corners (Glassmorphism feel)
            background = GradientDrawable().apply {
                setColor(0xD90F172A.toInt()) // 85% Slate dark
                cornerRadius = dpToPx(16f).toFloat()
                setStroke(2, 0xFF3B82F6.toInt()) // Sleek Blue Outline
            }
        }

        // 1. Drag Handle
        dragHandle = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(14f)
            ).apply {
                setMargins(0, 0, 0, dpToPx(4f))
            }
            background = GradientDrawable().apply {
                setColor(0x33FFFFFF) // Subtle grab handle line
                cornerRadius = dpToPx(6f).toFloat()
            }
        }
        widgetView.addView(dragHandle)

        // 2. Content Row
        val contentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(8f), dpToPx(4f), dpToPx(8f), dpToPx(4f))
        }

        // Left Controls: Play + Size + Speed Text
        val leftControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Play Button
        btnPlay = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(34f), dpToPx(34f)).apply {
                rightMargin = dpToPx(6f)
            }
            text = "▶"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply {
                setColor(0xFF3B82F6.toInt()) // Accent Blue
                cornerRadius = dpToPx(10f).toFloat()
            }
            setOnClickListener { togglePlayState() }
        }
        leftControls.addView(btnPlay)

        // Size Button (Resizable scale switcher)
        btnSize = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(34f), dpToPx(34f)).apply {
                rightMargin = dpToPx(6f)
            }
            text = "1.0"
            textSize = 10f
            setTextColor(0xFF3B82F6.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(0x1A3B82F6.toInt()) // Subtle blue background
                cornerRadius = dpToPx(10f).toFloat()
                setStroke(1, 0x4D3B82F6.toInt())
            }
            setOnClickListener { toggleSizeScale() }
        }
        leftControls.addView(btnSize)

        // Speed Text Badge
        txtSpeed = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(34f), dpToPx(22f)).apply {
                rightMargin = dpToPx(6f)
            }
            text = "1.5"
            textSize = 10f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0x40000000)
                cornerRadius = dpToPx(6f).toFloat()
            }
        }
        leftControls.addView(txtSpeed)
        contentRow.addView(leftControls)

        // Speed Slider Panel (Starts Hidden)
        panelSlider = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
            setPadding(dpToPx(4f), 0, dpToPx(4f), 0)
        }

        val sliderHeader = TextView(this).apply {
            text = "속도 조절"
            textSize = 8f
            setTextColor(0xFF94A3B8.toInt())
        }
        panelSlider.addView(sliderHeader)

        speedSlider = SeekBar(this).apply {
            max = 58 // 0.2 to 6.0 in 0.1 steps
            progress = 13 // 1.5x default
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentSpeedIndex = progress
                    val speed = 0.2f + (currentSpeedIndex * 0.1f)
                    txtSpeed.text = String.format("%.1f", speed)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        panelSlider.addView(speedSlider)
        contentRow.addView(panelSlider)

        // Toggle Drawer Button
        btnToggle = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(16f), dpToPx(34f))
            text = "◀"
            textSize = 8f
            setTextColor(0xFF94A3B8.toInt())
            background = null
            setOnClickListener { toggleDrawerPanel() }
        }
        contentRow.addView(btnToggle)
        widgetView.addView(contentRow)

        // Window Layout Parameters Setup
        val flag = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION.SDK_INT) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }

        layoutParams = WindowManager.LayoutParams(
            dpToPx(126f), // Initial width (Collapsed)
            dpToPx(64f),  // Initial height
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = dpToPx(20f)
            y = dpToPx(100f)
        }

        windowManager.addView(widgetView, layoutParams)

        // Bind Drag and drop listener to the handle
        setupDragListener()
    }

    private fun togglePlayState() {
        isPlaying = !isPlaying
        if (isPlaying) {
            btnPlay.text = "‖"
            btnPlay.background = GradientDrawable().apply {
                setColor(0xFFEF4444.toInt()) // Crimson Red when playing
                cornerRadius = dpToPx(10f).toFloat()
            }
            startScrollTimer()
        } else {
            btnPlay.text = "▶"
            btnPlay.background = GradientDrawable().apply {
                setColor(0xFF3B82F6.toInt()) // Royal Blue when paused
                cornerRadius = dpToPx(10f).toFloat()
            }
            stopScrollTimer()
        }
    }

    private fun startScrollTimer() {
        scrollRunnable = object : Runnable {
            override fun run() {
                if (!isPlaying) return

                val speed = 0.2f + (currentSpeedIndex * 0.1f)
                
                // Broadcast the scroll command to the Accessibility Service
                val intent = Intent(AutoScrollAccessibilityService.ACTION_SCROLL).apply {
                    putExtra(AutoScrollAccessibilityService.EXTRA_SPEED, speed)
                }
                sendBroadcast(intent)

                // Loop periodically. Interval depends on speed (higher speed = faster swipe frequency)
                val baseInterval = 450L
                handler.postDelayed(this, baseInterval)
            }
        }
        handler.post(scrollRunnable!!)
    }

    private fun stopScrollTimer() {
        scrollRunnable?.let { handler.removeCallbacks(it) }
        scrollRunnable = null
    }

    private fun toggleDrawerPanel() {
        isExpanded = !isExpanded
        if (isExpanded) {
            panelSlider.visibility = View.VISIBLE
            btnToggle.text = "▶"
            updateWidgetDimensions()
        } else {
            panelSlider.visibility = View.GONE
            btnToggle.text = "◀"
            updateWidgetDimensions()
        }
    }

    /**
     * 📏 Sizing/Scale scaling toggled natively!
     */
    private fun toggleSizeScale() {
        currentScaleIndex = (currentScaleIndex + 1) % scales.size
        btnSize.text = scaleLabels[currentScaleIndex]
        updateWidgetDimensions()
    }

    private fun updateWidgetDimensions() {
        val scale = scales[currentScaleIndex]
        
        val baseWidth = if (isExpanded) 280f else 134f
        val baseHeight = 66f

        layoutParams.width = dpToPx(baseWidth * scale)
        layoutParams.height = dpToPx(baseHeight * scale)
        windowManager.updateViewLayout(widgetView, layoutParams)
    }

    private fun setupDragListener() {
        var startX = 0
        var startY = 0
        var initialX = 0
        var initialY = 0

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    startX = event.rawX.toInt()
                    startY = event.rawY.toInt()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.rawX.toInt() - startX
                    val deltaY = event.rawY.toInt() - startY
                    // Update positions relative to screens
                    layoutParams.x = initialX - deltaX
                    layoutParams.y = initialY - deltaY
                    windowManager.updateViewLayout(widgetView, layoutParams)
                    true
                }
                else -> false
            }
        }
    }

    private fun dpToPx(dp: Float): Int {
        val density = resources.displayMetrics.density
        return Math.round(dp * density)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopScrollTimer()
        try {
            windowManager.removeView(widgetView)
        } catch (e: Exception) {
            // Already removed
        }
    }
}
