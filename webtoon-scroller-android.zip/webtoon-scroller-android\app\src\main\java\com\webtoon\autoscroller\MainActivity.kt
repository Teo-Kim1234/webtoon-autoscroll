package com.webtoon.autoscroller

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var btnOverlay: Button
    private lateinit var btnAccessibility: Button
    private lateinit var btnStartWidget: Button
    private lateinit var btnStopWidget: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Dynamic UI Generation using basic Android layouts
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(60, 80, 60, 80)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            background = android.graphics.drawable.ColorDrawable(0xFF1E293B.toInt()) // Sleek Dark Slate
        }

        // Header Title
        val titleText = TextView(this).apply {
            text = "웹툰 자동 스크롤러 Premium"
            textSize = 24f
            setTextColor(0xFFF8FAFC.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 20)
        }
        container.addView(titleText)

        // Subtitle
        val subtitle = TextView(this).apply {
            text = "실제 모바일 네이버웹툰 앱 위에서 오버레이로 작동하는 스마트 자동 스크롤러입니다."
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(0, 0, 0, 60)
        }
        container.addView(subtitle)

        // Status Indicator Card
        statusText = TextView(this).apply {
            text = "상태 로딩 중..."
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = android.view.Gravity.CENTER
            setPadding(40, 40, 40, 40)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF0F172A.toInt())
                cornerRadius = 24f
                setStroke(2, 0xFF334155.toInt())
            }
        }
        container.addView(statusText)

        // Divider
        container.addView(TextView(this).apply { height = 50 })

        // Button: Grant Overlay Permission
        btnOverlay = Button(this).apply {
            text = "1. 다른 앱 위에 그리기 권한 허용"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF3B82F6.toInt()) // Modern Accent Blue
                cornerRadius = 16f
            }
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    Toast.makeText(this@MainActivity, "이미 오버레이 권한이 허용되어 있습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        container.addView(btnOverlay)
        container.addView(TextView(this).apply { height = 30 })

        // Button: Grant Accessibility Service
        btnAccessibility = Button(this).apply {
            text = "2. 접근성 서비스 켜기 (제스처용)"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF10B981.toInt()) // Modern Emerald Green
                cornerRadius = 16f
            }
            setOnClickListener {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                startActivity(intent)
                Toast.makeText(this@MainActivity, "[웹툰 프리미엄 자동 스크롤러] 서비스를 찾아 활성화해주세요.", Toast.LENGTH_LONG).show()
            }
        }
        container.addView(btnAccessibility)
        container.addView(TextView(this).apply { height = 50 })

        // Button: Start Widget
        btnStartWidget = Button(this).apply {
            text = "🚀 스크롤 오버레이 위젯 실행!"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF8B5CF6.toInt()) // Deep Premium Purple
                cornerRadius = 20f
            }
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "다른 앱 위에 그리기 권한이 필요합니다.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                
                // Start Widget Service
                val serviceIntent = Intent(this@MainActivity, FloatingWidgetService::class.java)
                startService(serviceIntent)
                Toast.makeText(this@MainActivity, "바깥 화면에 오버레이 위젯이 실행되었습니다. 웹툰 앱으로 가세요!", Toast.LENGTH_LONG).show()
                
                // Go to home screen so they can open webtoon app
                val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(homeIntent)
            }
        }
        container.addView(btnStartWidget)
        container.addView(TextView(this).apply { height = 30 })

        // Button: Stop Widget
        btnStopWidget = Button(this).apply {
            text = "정지 (위젯 닫기)"
            textSize = 13f
            setTextColor(0xFF94A3B8.toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xFF334155.toInt())
                cornerRadius = 16f
            }
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingWidgetService::class.java))
                Toast.makeText(this@MainActivity, "위젯 서비스가 정지되었습니다.", Toast.LENGTH_SHORT).show()
            }
        }
        container.addView(btnStopWidget)

        setContentView(container)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val overlayAllowed = Settings.canDrawOverlays(this)
        val accessibilityAllowed = isAccessibilityServiceEnabled(this, AutoScrollAccessibilityService::class.java)

        val status = StringBuilder()
        status.append("📌 필수 권한 및 활성화 상태\n\n")
        status.append("• 오버레이 권한: ${if (overlayAllowed) "🟢 허용됨" else "🔴 허용 안 됨"}\n")
        status.append("• 접근성 서비스: ${if (accessibilityAllowed) "🟢 켜짐" else "🔴 꺼짐"}\n\n")

        if (overlayAllowed && accessibilityAllowed) {
            status.append("💡 준비 완료! 🚀 버튼을 클릭하여 웹툰 앱으로 가세요.")
        } else {
            status.append("⚠️ 위의 1번과 2번 권한을 먼저 허용해주세요.")
        }

        statusText.text = status.toString()
    }

    private fun isAccessibilityServiceEnabled(context: Context, service: Class<*>): Boolean {
        val expectedId = "${context.packageName}/${service.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return enabledServices.split(':').any { it.trim().equals(expectedId, ignoreCase = true) }
    }
}
