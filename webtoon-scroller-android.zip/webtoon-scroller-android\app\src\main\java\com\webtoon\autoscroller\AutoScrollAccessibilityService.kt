package com.webtoon.autoscroller

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent

class AutoScrollAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_SCROLL = "com.webtoon.autoscroller.SCROLL_COMMAND"
        const val EXTRA_SPEED = "EXTRA_SPEED"
        
        private var instance: AutoScrollAccessibilityService? = null
        fun getInstance(): AutoScrollAccessibilityService? = instance
    }

    private val scrollReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_SCROLL) {
                val speed = intent.getFloatExtra(EXTRA_SPEED, 1.5f)
                performScrollGesture(speed)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val filter = IntentFilter(ACTION_SCROLL)
        registerReceiver(scrollReceiver, filter)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        try {
            unregisterReceiver(scrollReceiver)
        } catch (e: Exception) {
            // Ignore
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No-op
    }

    override fun onInterrupt() {
        // No-op
    }

    /**
     * 지정된 속도 비율에 맞춰 하단에서 상단으로 드래그 제스처를 인공 주입합니다.
     */
    fun performScrollGesture(speed: Float) {
        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val screenHeight = metrics.heightPixels

        // 터치 시작점 (화면 중앙-하단)
        val startX = screenWidth / 2f
        val startY = screenHeight * 0.75f

        // 스와이프 길이 (속도 1.5x일 때 약 150px 위로 드래그)
        val dragLength = 50f * speed
        val endY = startY - dragLength

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX, endY)
        }

        // 제스처 지속 시간 (낮을수록 빠르게 확 스크롤되고, 적절하면 매우 부드럽게 흘러감)
        val duration = 400L // 400ms 동안 드래그

        val gestureBuilder = GestureDescription.Builder()
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        gestureBuilder.addStroke(stroke)

        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                // 제스처가 성공적으로 입력됨
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                // 취소됨
            }
        }, null)
    }
}
