/**
 * 🚀 Webtoon Auto-Scroller Premium Injected Script
 * Bulletproof, error-resistant implementation with absolute z-index and CSP bypass.
 */

(function () {
    // Prevent duplicate injection
    if (document.getElementById('wt-scroller-widget')) return;

    // Wait until document.body is fully ready
    function initScroller() {
        if (document.getElementById('wt-scroller-widget')) return;
        if (!document.body) {
            // If body is still not ready, retry in 100ms
            setTimeout(initScroller, 100);
            return;
        }

        // === SVG Icons Source ===
        const SVGS = {
            play: `<svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor"><path d="M8 5v14l11-7z"/></svg>`,
            pause: `<svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>`,
            chevronLeft: `<svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>`,
            chevronRight: `<svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>`
        };

        // === Create Injected elements ===
        const widget = document.createElement('div');
        widget.id = 'wt-scroller-widget';
        widget.className = 'wt-scroller-container';
        widget.innerHTML = `
            <div class="wt-drag-handle" id="wt-drag-handle">
                <div class="wt-drag-bar-line"></div>
            </div>
            <div class="wt-widget-content">
                <div class="wt-left-controls">
                    <button class="wt-btn wt-play-btn" id="wt-play-btn" title="자동 스크롤 재생/정지">
                        ${SVGS.play}
                    </button>
                    <button class="wt-btn wt-size-btn" id="wt-size-btn" title="크기 변경 (S/M/L/XL)" style="width: 34px; height: 34px; min-width: 34px;">1.0x</button>
                    <div class="wt-speed-indicator">
                        <span id="wt-speed-val">1.5x</span>
                    </div>
                </div>
                
                <div class="wt-slider-panel" id="wt-slider-panel">
                    <div class="wt-slider-header">자동 스크롤 속도</div>
                    <div class="wt-slider-wrapper">
                        <span style="font-size: 0.65rem; color:#94a3b8; font-weight:700; user-select:none;">Min</span>
                        <input type="range" id="wt-speed-slider" class="wt-speed-slider" min="0.2" max="6" step="0.1" value="1.5">
                        <span style="font-size: 0.65rem; color:#94a3b8; font-weight:700; user-select:none;">Max</span>
                    </div>
                </div>
                
                <button class="wt-btn wt-toggle-panel-btn" id="wt-toggle-panel-btn" title="패널 열기/닫기">
                    ${SVGS.chevronLeft}
                </button>
            </div>
        `;

        const toast = document.createElement('div');
        toast.className = 'wt-toast';
        toast.id = 'wt-scroller-toast';
        toast.textContent = '';

        // Inject into body
        document.body.appendChild(widget);
        document.body.appendChild(toast);

        // === Query DOM elements ===
        const playBtn = document.getElementById('wt-play-btn');
        const speedVal = document.getElementById('wt-speed-val');
        const speedSlider = document.getElementById('wt-speed-slider');
        const togglePanelBtn = document.getElementById('wt-toggle-panel-btn');
        const dragHandle = document.getElementById('wt-drag-handle');
        const sizeBtn = document.getElementById('wt-size-btn');

        if (!playBtn || !speedVal || !speedSlider || !togglePanelBtn || !dragHandle || !sizeBtn) {
            console.error('[Webtoon Scroller] Failed to initialize DOM elements.');
            return;
        }

        // === Global States ===
        let isPlaying = false;
        let currentSpeed = parseFloat(speedSlider.value) || 1.5;
        let isExpanded = false;
        let scrollAnimId = null;
        let dimTimeout = null;

        // Draggable Variables
        let isDragging = false;
        let startX, startY;

        // === Drag and Drop (Desktop + Mobile) ===
        dragHandle.addEventListener('mousedown', startDrag);
        dragHandle.addEventListener('touchstart', startDrag, { passive: false });

        function startDrag(e) {
            isDragging = true;
            widget.classList.remove('dimmed'); // Remove dimming when user touches
            clearTimeout(dimTimeout);

            const clientX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;

            const rect = widget.getBoundingClientRect();
            startX = clientX - rect.left;
            startY = clientY - rect.top;

            document.addEventListener('mousemove', drag);
            document.addEventListener('mouseup', endDrag);
            document.addEventListener('touchmove', drag, { passive: false });
            document.addEventListener('touchend', endDrag);

            if (e.cancelable) e.preventDefault();
        }

        function drag(e) {
            if (!isDragging) return;

            const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;

            let left = clientX - startX;
            let top = clientY - startY;

            // Constraint checking inside browser window viewport
            const maxLeft = window.innerWidth - widget.clientWidth - 10;
            const maxTop = window.innerHeight - widget.clientHeight - 10;

            if (left < 10) left = 10;
            if (left > maxLeft) left = maxLeft;
            if (top < 10) top = 10;
            if (top > maxTop) top = maxTop;

            widget.style.left = `${left}px`;
            widget.style.top = `${top}px`;
            widget.style.bottom = 'auto';
            widget.style.right = 'auto';

            if (e.cancelable) e.preventDefault();
        }

        function endDrag() {
            isDragging = false;
            document.removeEventListener('mousemove', drag);
            document.removeEventListener('mouseup', endDrag);
            document.removeEventListener('touchmove', drag);
            document.removeEventListener('touchend', endDrag);

            if (isPlaying) {
                triggerDimmer();
            }
        }

        // === Smooth Auto-Scroll Core Loop ===
        function autoScroll() {
            if (!isPlaying) return;

            // Base increment per frame.
            const increment = currentSpeed * 0.95;
            
            const prevScrollY = window.scrollY || document.documentElement.scrollTop;
            window.scrollBy(0, increment);
            const currentScrollY = window.scrollY || document.documentElement.scrollTop;

            // Detection of page end (if scroll stopped moving)
            const isPageEnd = (prevScrollY === currentScrollY && prevScrollY > 0 && Math.abs(window.innerHeight + currentScrollY - document.documentElement.scrollHeight) < 10);

            if (isPageEnd) {
                pauseScrolling();
                showToast('웹툰 페이지 끝에 도달하여 자동 스크롤을 정지합니다.');
            } else {
                scrollAnimId = requestAnimationFrame(autoScroll);
            }
        }

        function startScrolling() {
            isPlaying = true;
            playBtn.classList.add('playing');
            playBtn.innerHTML = SVGS.pause;
            autoScroll();
            triggerDimmer();
        }

        function pauseScrolling() {
            isPlaying = false;
            playBtn.classList.remove('playing');
            playBtn.innerHTML = SVGS.play;
            if (scrollAnimId) cancelAnimationFrame(scrollAnimId);
            
            // Cancel dimming
            widget.classList.remove('dimmed');
            clearTimeout(dimTimeout);
        }

        // === Dimmer control during reading ===
        function triggerDimmer() {
            clearTimeout(dimTimeout);
            widget.classList.remove('dimmed');
            
            // Auto-fade widget after 3 seconds of scroll to enhance immersion
            dimTimeout = setTimeout(() => {
                if (isPlaying && !isDragging) {
                    widget.classList.add('dimmed');
                }
            }, 3000);
        }

        // === Events and bindings ===
        playBtn.addEventListener('click', () => {
            if (isPlaying) {
                pauseScrolling();
            } else {
                startScrolling();
            }
        });

        speedSlider.addEventListener('input', (e) => {
            currentSpeed = parseFloat(e.target.value);
            speedVal.textContent = `${currentSpeed.toFixed(1)}x`;
            triggerDimmer();
        });

        // Toggle Sizing Scale (S / M / L / XL)
        const sizes = ['scale-sm', 'scale-md', 'scale-lg', 'scale-xl'];
        const sizeLabels = ['0.8x', '1.0x', '1.2x', '1.4x'];
        let currentSizeIndex = 1; // Default to scale-md (1.0x)

        sizeBtn.addEventListener('click', () => {
            widget.classList.remove(sizes[currentSizeIndex]);
            currentSizeIndex = (currentSizeIndex + 1) % sizes.length;
            widget.classList.add(sizes[currentSizeIndex]);
            sizeBtn.textContent = sizeLabels[currentSizeIndex];
            showToast(`크기가 ${sizeLabels[currentSizeIndex]} 배율로 조절되었습니다.`);
            triggerDimmer();
        });

        // Expand speed panel toggle drawer
        togglePanelBtn.addEventListener('click', () => {
            isExpanded = !isExpanded;
            if (isExpanded) {
                widget.classList.add('expanded');
                togglePanelBtn.innerHTML = SVGS.chevronRight;
            } else {
                widget.classList.remove('expanded');
                togglePanelBtn.innerHTML = SVGS.chevronLeft;
            }
            triggerDimmer();
        });

        // Hover resets opacity
        widget.addEventListener('mouseenter', () => {
            widget.classList.remove('dimmed');
            clearTimeout(dimTimeout);
        });

        widget.addEventListener('mouseleave', () => {
            if (isPlaying) {
                triggerDimmer();
            }
        });

        // Toast Generator
        function showToast(text) {
            toast.textContent = text;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 2500);
        }

        // Initial alert
        showToast('🚀 웹툰 프리미엄 자동 스크롤러 활성화!');
    }

    // Run when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initScroller);
    } else {
        initScroller();
    }
})();
